# GECCO 2026 Competition Submission

## Author

Ahmed Kheiri

## Description

This submission contains a Python-based optimizer for the GECCO 2026 Explainable Ride-Sharing Optimisation Competition.

The submission is packaged as a Docker container and connects to the competition simulator via WebSocket and HTTP interfaces.

---

## Build Instructions

Build the Docker image:

```bash
docker build -t gecco-ahmed .
```

---

## Running the Optimizer

### Windows

If the simulator is running on the host machine:

```powershell
docker run --rm `
-e SIM_HOST=host.docker.internal `
-e SIM_PORT=8088 `
gecco-ahmed
```

### Linux

If the simulator is running on the host machine:

```bash
docker run --rm \
--network host \
-e SIM_HOST=localhost \
-e SIM_PORT=8088 \
gecco-ahmed
```

---

## Environment Variables

The optimizer supports the following optional environment variables:

| Variable  | Default   | Description    |
| --------- | --------- | -------------- |
| SIM_HOST  | localhost | Simulator host |
| SIM_PORT  | 8088      | Simulator port |
| LOG_LEVEL | INFO      | Logging level  |

---

## Connection Endpoints

The optimizer connects to:

WebSocket:

```text
ws://<SIM_HOST>:<SIM_PORT>/simulation-websocket
```

HTTP:

```text
http://<SIM_HOST>:<SIM_PORT>
```

---

## Notes

The optimizer is designed to operate continuously for the full simulation horizon and automatically reconnect if the simulator connection is temporarily lost.

No additional configuration is required beyond providing access to the simulator endpoints.
